import React, { useEffect, useState } from "react";
import { Routes, Route, Link, NavLink } from "react-router-dom";

function Navbar() {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
      <div className="container">
        <Link className="navbar-brand fw-bold" to="/">
          Employee Dashboard
        </Link>

        <div className="navbar-nav ms-auto">
          <NavLink
            to="/"
            className={({ isActive }) =>
              "nav-link px-3 " + (isActive ? "active fw-bold" : "")
            }
          >
            Home
          </NavLink>

          <NavLink
            to="/employee-form"
            className={({ isActive }) =>
              "nav-link px-3 " + (isActive ? "active fw-bold" : "")
            }
          >
            Employee Form
          </NavLink>
        </div>
      </div>
    </nav>
  );
}

function Dashboard() {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/users")
      .then((response) => {
        if (!response.ok) {
          throw new Error("API request failed");
        }
        return response.json();
      })
      .then((data) => {
        setEmployees(data);
        setLoading(false);
      })
      .catch(() => {
        setError("Unable to load data from the external API.");
        setLoading(false);
      });
  }, []);

  return (
    <div className="container py-5">
      <div className="p-4 p-md-5 mb-4 bg-white rounded-4 shadow-sm border">
        <h1 className="display-6 fw-bold">Employee Dashboard</h1>
        <p className="lead text-secondary mb-3">
          Employee details retrieved from JSONPlaceholder API.
        </p>
        <Link to="/employee-form" className="btn btn-primary">
          Add Employee
        </Link>
      </div>

      <div className="card shadow-sm border-0">
        <div className="card-header bg-white">
          <h4 className="mb-0">Employee List</h4>
        </div>

        <div className="table-responsive">
          <table className="table table-hover mb-0">
            <thead className="table-primary">
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
              </tr>
            </thead>

            <tbody>
              {loading && (
                <tr>
                  <td colSpan="3" className="text-center py-4">
                    Loading employee data...
                  </td>
                </tr>
              )}

              {!loading && error && (
                <tr>
                  <td colSpan="3" className="text-center text-danger py-4">
                    {error}
                  </td>
                </tr>
              )}

              {!loading &&
                !error &&
                employees.map((employee) => (
                  <tr key={employee.id}>
                    <td>{employee.id}</td>
                    <td className="fw-semibold">{employee.name}</td>
                    <td>{employee.email}</td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function EmployeeForm() {
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit(event) {
    event.preventDefault();
    setSubmitted(true);
  }

  return (
    <div className="container py-5">
      <div className="form-card bg-white p-4 p-md-5 rounded-4 shadow-sm border">
        <h1 className="fw-bold mb-2">Employee Form</h1>
        <p className="text-secondary mb-4">
          Enter the employee details below.
        </p>

        {submitted && (
          <div className="alert alert-success">
            Employee details submitted successfully!
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="row g-3">
            <div className="col-md-6">
              <label className="form-label">Name</label>
              <input
                type="text"
                className="form-control"
                placeholder="Enter name"
                required
              />
            </div>

            <div className="col-md-6">
              <label className="form-label">Designation</label>
              <input
                type="text"
                className="form-control"
                placeholder="Enter designation"
                required
              />
            </div>

            <div className="col-md-6">
              <label className="form-label">Location</label>
              <input
                type="text"
                className="form-control"
                placeholder="Enter location"
                required
              />
            </div>

            <div className="col-md-6">
              <label className="form-label">Salary</label>
              <input
                type="number"
                className="form-control"
                placeholder="Enter salary"
                min="0"
                required
              />
            </div>

            <div className="col-12 mt-4">
              <button type="submit" className="btn btn-primary me-2">
                Submit
              </button>

              <Link to="/" className="btn btn-outline-secondary">
                Back to Home
              </Link>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

function App() {
  return (
    <>
      <Navbar />

      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/employee-form" element={<EmployeeForm />} />
      </Routes>

      <footer className="text-center text-secondary py-4">
        Assignment 2 | PS Ashin
      </footer>
    </>
  );
}

export default App;