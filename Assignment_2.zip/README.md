# Assignment 2 - Employee Dashboard

Student: PS Ashin

## Requirements
- React library
- Navbar with Home and Employee Form
- Employee Dashboard/Home
- Data fetched from https://jsonplaceholder.typicode.com/users
- Table showing ID, Name and Email
- Employee Form: Name, Designation, Location and Salary
- React Router navigation
- Bootstrap CSS library

## Run
Open Command Prompt in this folder and run:

npm install

Then:

npm run dev

Open the localhost address shown in the terminal.

## Important
If an old Vite server is running, press Ctrl+C first and then run the commands above.
